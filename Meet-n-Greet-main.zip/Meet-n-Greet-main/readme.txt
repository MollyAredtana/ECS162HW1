Group # 14
Names: Alvin Agana, Xuan Huang, James Junaidi, Ethan Nagano, Jackie Ou, Ishani Pandya
